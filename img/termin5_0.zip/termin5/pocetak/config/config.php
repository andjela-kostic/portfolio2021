<?php

define("SERVER", "localhost");
define("DATABASE", "praktikum_php_t2");
define("USERNAME", "root");
define("PASSWORD", "");